import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/LoginView.vue");import { ref } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"
import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=b23d26c1"
import { login } from "/src/services/api.js"


const _sfc_main = {
  __name: 'LoginView',
  setup(__props, { expose: __expose }) {
  __expose();

const email = ref('')
const password = ref('')
const router = useRouter()

const handleLogin = async () => {
  // validation coming in v2 :)
  await login(email.value, password.value)
  localStorage.setItem('kraftly_logged_in', 'true')
  router.push('/')
}

const __returned__ = { email, password, router, handleLogin, ref, get useRouter() { return useRouter }, get login() { return login } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"

const _hoisted_1 = { class: "login-wrap" }
const _hoisted_2 = { class: "card login-card" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", _hoisted_1, [
    _createElementVNode("div", _hoisted_2, [
      _cache[2] || (_cache[2] = _createElementVNode("img", {
        src: "/src/assets/logo-dark.svg",
        class: "login-logo"
      }, null, -1 /* CACHED */)),
      _cache[3] || (_cache[3] = _createElementVNode("h1", null, "Logga in på Mina sidor", -1 /* CACHED */)),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "E-postadress",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.email) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.email]
      ]),
      _withDirectives(_createElementVNode("input", {
        type: "password",
        placeholder: "Lösenord",
        "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.password) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.password]
      ]),
      _createElementVNode("button", {
        class: "btn",
        style: {"width":"100%"},
        onClick: $setup.handleLogin
      }, "Logga in"),
      _cache[4] || (_cache[4] = _createElementVNode("p", {
        class: "hint",
        style: {"margin-top":"10px"}
      }, "Problem att logga in? Ring kundservice 020-123 456", -1 /* CACHED */))
    ])
  ]))
}

import "/src/views/LoginView.vue?vue&type=style&index=0&scoped=45f5edd7&lang.css"

_sfc_main.__hmrId = "45f5edd7"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-45f5edd7"],['__file',"/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/views/LoginView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTG9naW5WaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxkaXYgY2xhc3M9XCJsb2dpbi13cmFwXCI+XG4gICAgPGRpdiBjbGFzcz1cImNhcmQgbG9naW4tY2FyZFwiPlxuICAgICAgPGltZyBzcmM9XCIuLi9hc3NldHMvbG9nby1kYXJrLnN2Z1wiIGNsYXNzPVwibG9naW4tbG9nb1wiPlxuICAgICAgPGgxPkxvZ2dhIGluIHDDpSBNaW5hIHNpZG9yPC9oMT5cbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiRS1wb3N0YWRyZXNzXCIgdi1tb2RlbD1cImVtYWlsXCI+XG4gICAgICA8aW5wdXQgdHlwZT1cInBhc3N3b3JkXCIgcGxhY2Vob2xkZXI9XCJMw7ZzZW5vcmRcIiB2LW1vZGVsPVwicGFzc3dvcmRcIj5cbiAgICAgIDxidXR0b24gY2xhc3M9XCJidG5cIiBzdHlsZT1cIndpZHRoOjEwMCVcIiBAY2xpY2s9XCJoYW5kbGVMb2dpblwiPkxvZ2dhIGluPC9idXR0b24+XG4gICAgICA8cCBjbGFzcz1cImhpbnRcIiBzdHlsZT1cIm1hcmdpbi10b3A6MTBweFwiPlByb2JsZW0gYXR0IGxvZ2dhIGluPyBSaW5nIGt1bmRzZXJ2aWNlIDAyMC0xMjMgNDU2PC9wPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyByZWYgfSBmcm9tICd2dWUnXG5pbXBvcnQgeyB1c2VSb3V0ZXIgfSBmcm9tICd2dWUtcm91dGVyJ1xuaW1wb3J0IHsgbG9naW4gfSBmcm9tICcuLi9zZXJ2aWNlcy9hcGknXG5cbmNvbnN0IGVtYWlsID0gcmVmKCcnKVxuY29uc3QgcGFzc3dvcmQgPSByZWYoJycpXG5jb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKVxuXG5jb25zdCBoYW5kbGVMb2dpbiA9IGFzeW5jICgpID0+IHtcbiAgLy8gdmFsaWRhdGlvbiBjb21pbmcgaW4gdjIgOilcbiAgYXdhaXQgbG9naW4oZW1haWwudmFsdWUsIHBhc3N3b3JkLnZhbHVlKVxuICBsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgna3JhZnRseV9sb2dnZWRfaW4nLCAndHJ1ZScpXG4gIHJvdXRlci5wdXNoKCcvJylcbn1cbjwvc2NyaXB0PlxuXG48c3R5bGUgc2NvcGVkPlxuLmxvZ2luLXdyYXAgeyBkaXNwbGF5OiBmbGV4OyBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjsgcGFkZGluZy10b3A6IDYwcHg7IH1cbi5sb2dpbi1jYXJkIHsgd2lkdGg6IDM4MHB4OyB9XG4ubG9naW4tbG9nbyB7IGhlaWdodDogMzRweDsgbWFyZ2luLWJvdHRvbTogMThweDsgfVxuPC9zdHlsZT5cbiJdLCJtYXBwaW5ncyI6IkFBY0EsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7O0FBRXRDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFekIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2hDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzlCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN6QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pCOzs7Ozs7Ozs7O3FCQTFCTyxLQUFLLEVBQUMsWUFBWTtxQkFDaEIsS0FBSyxFQUFDLGlCQUFpQjs7O3dCQUQ5QixvQkFTTSxPQVROLFVBU007SUFSSixvQkFPTSxPQVBOLFVBT007Z0NBTkosb0JBQXNEO1FBQWpELEdBQUcsRUFBQywyQkFBeUI7UUFBQyxLQUFLLEVBQUMsWUFBWTs7Z0NBQ3JELG9CQUErQixZQUEzQix3QkFBc0I7c0JBQzFCLG9CQUE4RDtRQUF2RCxJQUFJLEVBQUMsTUFBTTtRQUFDLFdBQVcsRUFBQyxjQUFjO3FFQUFVLFlBQUs7O3NCQUFMLFlBQUs7O3NCQUM1RCxvQkFBaUU7UUFBMUQsSUFBSSxFQUFDLFVBQVU7UUFBQyxXQUFXLEVBQUMsVUFBVTtxRUFBVSxlQUFROztzQkFBUixlQUFROztNQUMvRCxvQkFBNkU7UUFBckUsS0FBSyxFQUFDLEtBQUs7UUFBQyxLQUFrQixFQUFsQixnQkFBa0I7UUFBRSxPQUFLLEVBQUUsa0JBQVc7U0FBRSxVQUFRO2dDQUNwRSxvQkFBOEY7UUFBM0YsS0FBSyxFQUFDLE1BQU07UUFBQyxLQUF1QixFQUF2QixxQkFBdUI7U0FBQyxvREFBa0QiLCJpZ25vcmVMaXN0IjpbXX0=