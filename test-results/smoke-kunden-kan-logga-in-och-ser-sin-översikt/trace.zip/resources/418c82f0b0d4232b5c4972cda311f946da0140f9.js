import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/MoveFormView.vue");import { ref, reactive } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"
import BaseButton from "/src/components/BaseButton.vue"
import { submitMove } from "/src/services/api.js"
import { validateMove } from "/src/utils/validateMove.js"


const _sfc_main = {
  __name: 'MoveFormView',
  setup(__props, { expose: __expose }) {
  __expose();

const form = reactive({ address: '', zip: '', city: '', date: '', contract: '' })
const reference = ref(null)
const errors = ref({})

const submit = async () => {
  const validationErrors = validateMove(form, new Date())
  errors.value = validationErrors

  if (Object.keys(validationErrors).length > 0) {
    return
  }

  const res = await submitMove(form)
  reference.value = res.ref
}

const __returned__ = { form, reference, errors, submit, ref, reactive, BaseButton, get submitMove() { return submitMove }, get validateMove() { return validateMove } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, vModelText as _vModelText, withDirectives as _withDirectives, toDisplayString as _toDisplayString, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode, vModelSelect as _vModelSelect, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"

const _hoisted_1 = {
  class: "card",
  style: {"max-width":"560px"}
}
const _hoisted_2 = {
  key: 0,
  class: "error"
}
const _hoisted_3 = {
  key: 1,
  class: "error"
}
const _hoisted_4 = {
  key: 2,
  class: "error"
}
const _hoisted_5 = {
  key: 3,
  class: "error"
}
const _hoisted_6 = {
  key: 4,
  class: "error"
}
const _hoisted_7 = {
  key: 5,
  style: {"color":"#12b76a","margin-top":"10px"}
}

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    _cache[9] || (_cache[9] = _createElementVNode("h1", null, "Flyttanmälan", -1 /* CACHED */)),
    _createElementVNode("div", _hoisted_1, [
      _cache[7] || (_cache[7] = _createElementVNode("p", { style: {"margin-bottom":"14px"} }, "Fyll i uppgifterna nedan så flyttar vi ditt elavtal.", -1 /* CACHED */)),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "Ny adress",
        "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.form.address) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.form.address]
      ]),
      ($setup.errors.address)
        ? (_openBlock(), _createElementBlock("p", _hoisted_2, _toDisplayString($setup.errors.address), 1 /* TEXT */))
        : _createCommentVNode("v-if", true),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "Postnummer",
        "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.form.zip) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.form.zip]
      ]),
      ($setup.errors.zip)
        ? (_openBlock(), _createElementBlock("p", _hoisted_3, _toDisplayString($setup.errors.zip), 1 /* TEXT */))
        : _createCommentVNode("v-if", true),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "Ort",
        "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.form.city) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.form.city]
      ]),
      ($setup.errors.city)
        ? (_openBlock(), _createElementBlock("p", _hoisted_4, _toDisplayString($setup.errors.city), 1 /* TEXT */))
        : _createCommentVNode("v-if", true),
      _withDirectives(_createElementVNode("input", {
        type: "text",
        placeholder: "Inflyttningsdatum (ÅÅÅÅ-MM-DD)",
        "onUpdate:modelValue": _cache[3] || (_cache[3] = $event => (($setup.form.date) = $event))
      }, null, 512 /* NEED_PATCH */), [
        [_vModelText, $setup.form.date]
      ]),
      ($setup.errors.date)
        ? (_openBlock(), _createElementBlock("p", _hoisted_5, _toDisplayString($setup.errors.date), 1 /* TEXT */))
        : _createCommentVNode("v-if", true),
      _withDirectives(_createElementVNode("select", {
        "onUpdate:modelValue": _cache[4] || (_cache[4] = $event => (($setup.form.contract) = $event))
      }, [...(_cache[5] || (_cache[5] = [
        _createElementVNode("option", {
          disabled: "",
          value: ""
        }, "Välj avtal", -1 /* CACHED */),
        _createElementVNode("option", null, "Rörligt pris", -1 /* CACHED */),
        _createElementVNode("option", null, "Fast pris 1 år", -1 /* CACHED */),
        _createElementVNode("option", null, "Fast pris 3 år", -1 /* CACHED */)
      ]))], 512 /* NEED_PATCH */), [
        [_vModelSelect, $setup.form.contract]
      ]),
      ($setup.errors.contract)
        ? (_openBlock(), _createElementBlock("p", _hoisted_6, _toDisplayString($setup.errors.contract), 1 /* TEXT */))
        : _createCommentVNode("v-if", true),
      _createVNode($setup["BaseButton"], { onClick: $setup.submit }, {
        default: _withCtx(() => [...(_cache[6] || (_cache[6] = [
          _createTextVNode("Skicka flyttanmälan", -1 /* CACHED */)
        ]))]),
        _: 1 /* STABLE */
      }),
      _cache[8] || (_cache[8] = _createElementVNode("p", {
        class: "hint",
        style: {"margin-top":"8px"}
      }, "Anmälan måste göras senast 14 dagar före flytt", -1 /* CACHED */)),
      ($setup.reference)
        ? (_openBlock(), _createElementBlock("p", _hoisted_7, "Tack! Referensnummer: " + _toDisplayString($setup.reference), 1 /* TEXT */))
        : _createCommentVNode("v-if", true)
    ])
  ]))
}


_sfc_main.__hmrId = "f7675b52"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/views/MoveFormView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiTW92ZUZvcm1WaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxkaXY+XG4gICAgPGgxPkZseXR0YW5tw6RsYW48L2gxPlxuICAgIDxkaXYgY2xhc3M9XCJjYXJkXCIgc3R5bGU9XCJtYXgtd2lkdGg6NTYwcHhcIj5cbiAgICAgIDxwIHN0eWxlPVwibWFyZ2luLWJvdHRvbToxNHB4XCI+RnlsbCBpIHVwcGdpZnRlcm5hIG5lZGFuIHPDpSBmbHl0dGFyIHZpIGRpdHQgZWxhdnRhbC48L3A+XG5cbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiTnkgYWRyZXNzXCIgdi1tb2RlbD1cImZvcm0uYWRkcmVzc1wiPlxuICAgICAgPHAgdi1pZj1cImVycm9ycy5hZGRyZXNzXCIgY2xhc3M9XCJlcnJvclwiPnt7IGVycm9ycy5hZGRyZXNzIH19PC9wPlxuXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIlBvc3RudW1tZXJcIiB2LW1vZGVsPVwiZm9ybS56aXBcIj5cbiAgICAgIDxwIHYtaWY9XCJlcnJvcnMuemlwXCIgY2xhc3M9XCJlcnJvclwiPnt7IGVycm9ycy56aXAgfX08L3A+XG5cbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHBsYWNlaG9sZGVyPVwiT3J0XCIgdi1tb2RlbD1cImZvcm0uY2l0eVwiPlxuICAgICAgPHAgdi1pZj1cImVycm9ycy5jaXR5XCIgY2xhc3M9XCJlcnJvclwiPnt7IGVycm9ycy5jaXR5IH19PC9wPlxuXG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiBwbGFjZWhvbGRlcj1cIkluZmx5dHRuaW5nc2RhdHVtICjDhcOFw4XDhS1NTS1ERClcIiB2LW1vZGVsPVwiZm9ybS5kYXRlXCI+XG4gICAgICA8cCB2LWlmPVwiZXJyb3JzLmRhdGVcIiBjbGFzcz1cImVycm9yXCI+e3sgZXJyb3JzLmRhdGUgfX08L3A+XG5cbiAgICAgIDxzZWxlY3Qgdi1tb2RlbD1cImZvcm0uY29udHJhY3RcIj5cbiAgICAgICAgPG9wdGlvbiBkaXNhYmxlZCB2YWx1ZT1cIlwiPlbDpGxqIGF2dGFsPC9vcHRpb24+XG4gICAgICAgIDxvcHRpb24+UsO2cmxpZ3QgcHJpczwvb3B0aW9uPlxuICAgICAgICA8b3B0aW9uPkZhc3QgcHJpcyAxIMOlcjwvb3B0aW9uPlxuICAgICAgICA8b3B0aW9uPkZhc3QgcHJpcyAzIMOlcjwvb3B0aW9uPlxuICAgICAgPC9zZWxlY3Q+XG4gICAgICA8cCB2LWlmPVwiZXJyb3JzLmNvbnRyYWN0XCIgY2xhc3M9XCJlcnJvclwiPnt7IGVycm9ycy5jb250cmFjdCB9fTwvcD5cblxuICAgICAgPEJhc2VCdXR0b24gQGNsaWNrPVwic3VibWl0XCI+U2tpY2thIGZseXR0YW5tw6RsYW48L0Jhc2VCdXR0b24+XG4gICAgICA8cCBjbGFzcz1cImhpbnRcIiBzdHlsZT1cIm1hcmdpbi10b3A6OHB4XCI+QW5tw6RsYW4gbcOlc3RlIGfDtnJhcyBzZW5hc3QgMTQgZGFnYXIgZsO2cmUgZmx5dHQ8L3A+XG4gICAgICA8cCB2LWlmPVwicmVmZXJlbmNlXCIgc3R5bGU9XCJjb2xvcjojMTJiNzZhO21hcmdpbi10b3A6MTBweFwiPlRhY2shIFJlZmVyZW5zbnVtbWVyOiB7eyByZWZlcmVuY2UgfX08L3A+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdCBzZXR1cD5cbmltcG9ydCB7IHJlZiwgcmVhY3RpdmUgfSBmcm9tICd2dWUnXG5pbXBvcnQgQmFzZUJ1dHRvbiBmcm9tICcuLi9jb21wb25lbnRzL0Jhc2VCdXR0b24udnVlJ1xuaW1wb3J0IHsgc3VibWl0TW92ZSB9IGZyb20gJy4uL3NlcnZpY2VzL2FwaSdcbmltcG9ydCB7IHZhbGlkYXRlTW92ZSB9IGZyb20gJy4uL3V0aWxzL3ZhbGlkYXRlTW92ZS5qcydcblxuY29uc3QgZm9ybSA9IHJlYWN0aXZlKHsgYWRkcmVzczogJycsIHppcDogJycsIGNpdHk6ICcnLCBkYXRlOiAnJywgY29udHJhY3Q6ICcnIH0pXG5jb25zdCByZWZlcmVuY2UgPSByZWYobnVsbClcbmNvbnN0IGVycm9ycyA9IHJlZih7fSlcblxuY29uc3Qgc3VibWl0ID0gYXN5bmMgKCkgPT4ge1xuICBjb25zdCB2YWxpZGF0aW9uRXJyb3JzID0gdmFsaWRhdGVNb3ZlKGZvcm0sIG5ldyBEYXRlKCkpXG4gIGVycm9ycy52YWx1ZSA9IHZhbGlkYXRpb25FcnJvcnNcblxuICBpZiAoT2JqZWN0LmtleXModmFsaWRhdGlvbkVycm9ycykubGVuZ3RoID4gMCkge1xuICAgIHJldHVyblxuICB9XG5cbiAgY29uc3QgcmVzID0gYXdhaXQgc3VibWl0TW92ZShmb3JtKVxuICByZWZlcmVuY2UudmFsdWUgPSByZXMucmVmXG59XG48L3NjcmlwdD5cbiJdLCJtYXBwaW5ncyI6IkFBa0NBLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNwRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzNDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7OztBQUV0RCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDaEYsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMzQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDeEQsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUVoQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNoRCxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNULENBQUMsQ0FBQzs7QUFFRixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzFCOzs7Ozs7Ozs7OztFQWxEUyxLQUFLLEVBQUMsTUFBTTtFQUFDLEtBQXVCLEVBQXZCLHFCQUF1Qjs7OztFQUlkLEtBQUssRUFBQyxPQUFPOzs7O0VBR2pCLEtBQUssRUFBQyxPQUFPOzs7O0VBR1osS0FBSyxFQUFDLE9BQU87Ozs7RUFHYixLQUFLLEVBQUMsT0FBTzs7OztFQVFULEtBQUssRUFBQyxPQUFPOzs7O0VBSW5CLEtBQXFDLEVBQXJDLHVDQUFxQzs7Ozt3QkEzQjdELG9CQTZCTTs4QkE1Qkosb0JBQXFCLFlBQWpCLGNBQVk7SUFDaEIsb0JBMEJNLE9BMUJOLFVBMEJNO2dDQXpCSixvQkFBc0YsT0FBbkYsS0FBMEIsRUFBMUIsd0JBQTBCLElBQUMsc0RBQW9EO3NCQUVsRixvQkFBa0U7UUFBM0QsSUFBSSxFQUFDLE1BQU07UUFBQyxXQUFXLEVBQUMsV0FBVztxRUFBVSxXQUFJLENBQUMsT0FBTzs7c0JBQVosV0FBSSxDQUFDLE9BQU87O09BQ3ZELGFBQU0sQ0FBQyxPQUFPO3lCQUF2QixvQkFBK0QsS0FBL0QsVUFBK0QsbUJBQXJCLGFBQU0sQ0FBQyxPQUFPOztzQkFFeEQsb0JBQStEO1FBQXhELElBQUksRUFBQyxNQUFNO1FBQUMsV0FBVyxFQUFDLFlBQVk7cUVBQVUsV0FBSSxDQUFDLEdBQUc7O3NCQUFSLFdBQUksQ0FBQyxHQUFHOztPQUNwRCxhQUFNLENBQUMsR0FBRzt5QkFBbkIsb0JBQXVELEtBQXZELFVBQXVELG1CQUFqQixhQUFNLENBQUMsR0FBRzs7c0JBRWhELG9CQUF5RDtRQUFsRCxJQUFJLEVBQUMsTUFBTTtRQUFDLFdBQVcsRUFBQyxLQUFLO3FFQUFVLFdBQUksQ0FBQyxJQUFJOztzQkFBVCxXQUFJLENBQUMsSUFBSTs7T0FDOUMsYUFBTSxDQUFDLElBQUk7eUJBQXBCLG9CQUF5RCxLQUF6RCxVQUF5RCxtQkFBbEIsYUFBTSxDQUFDLElBQUk7O3NCQUVsRCxvQkFBb0Y7UUFBN0UsSUFBSSxFQUFDLE1BQU07UUFBQyxXQUFXLEVBQUMsZ0NBQWdDO3FFQUFVLFdBQUksQ0FBQyxJQUFJOztzQkFBVCxXQUFJLENBQUMsSUFBSTs7T0FDekUsYUFBTSxDQUFDLElBQUk7eUJBQXBCLG9CQUF5RCxLQUF6RCxVQUF5RCxtQkFBbEIsYUFBTSxDQUFDLElBQUk7O3NCQUVsRCxvQkFLUztxRUFMUSxXQUFJLENBQUMsUUFBUTs7UUFDNUIsb0JBQTZDO1VBQXJDLFFBQVEsRUFBUixFQUFRO1VBQUMsS0FBSyxFQUFDLEVBQUU7V0FBQyxZQUFVO1FBQ3BDLG9CQUE2QixnQkFBckIsY0FBWTtRQUNwQixvQkFBK0IsZ0JBQXZCLGdCQUFjO1FBQ3RCLG9CQUErQixnQkFBdkIsZ0JBQWM7O3dCQUpQLFdBQUksQ0FBQyxRQUFROztPQU1yQixhQUFNLENBQUMsUUFBUTt5QkFBeEIsb0JBQWlFLEtBQWpFLFVBQWlFLG1CQUF0QixhQUFNLENBQUMsUUFBUTs7TUFFMUQsYUFBNEQsd0JBQS9DLE9BQUssRUFBRSxhQUFNOzBCQUFFLENBQW1COzJCQUFuQixxQkFBbUI7Ozs7Z0NBQy9DLG9CQUF5RjtRQUF0RixLQUFLLEVBQUMsTUFBTTtRQUFDLEtBQXNCLEVBQXRCLG9CQUFzQjtTQUFDLGdEQUE4QztPQUM1RSxnQkFBUzt5QkFBbEIsb0JBQW1HLEtBQW5HLFVBQW1HLEVBQXpDLHdCQUFzQixvQkFBRyxnQkFBUyIsImlnbm9yZUxpc3QiOltdfQ==