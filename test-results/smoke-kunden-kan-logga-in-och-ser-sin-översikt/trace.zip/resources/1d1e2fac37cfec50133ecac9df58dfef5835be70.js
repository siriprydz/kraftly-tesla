import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppButton.vue");
// new button for the profile page, the old one couldn't be themed /J
// TODO merge with BaseButton some day
const _sfc_main = {
  name: 'AppButton',
  props: { color: { type: String, default: '#2f54eb' } }
}

import { renderSlot as _renderSlot, normalizeStyle as _normalizeStyle, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("button", {
    class: "app-btn",
    style: _normalizeStyle({ background: $props.color })
  }, [
    _renderSlot(_ctx.$slots, "default", {}, undefined, true)
  ], 4 /* STYLE */))
}

import "/src/components/AppButton.vue?vue&type=style&index=0&scoped=19765ba3&lang.css"

_sfc_main.__hmrId = "19765ba3"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-19765ba3"],['__file',"/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/components/AppButton.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiL1VzZXJzL2pha29iaGFubmEvRG9jdW1lbnRzL1Byb2pla3QtYXJiZXRlbi9rcmFmdGx5LXRlc2xhL3NyYy9jb21wb25lbnRzL0FwcEJ1dHRvbi52dWUiLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwQnV0dG9uLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxidXR0b24gY2xhc3M9XCJhcHAtYnRuXCIgOnN0eWxlPVwieyBiYWNrZ3JvdW5kOiBjb2xvciB9XCI+PHNsb3QgLz48L2J1dHRvbj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQ+XG4vLyBuZXcgYnV0dG9uIGZvciB0aGUgcHJvZmlsZSBwYWdlLCB0aGUgb2xkIG9uZSBjb3VsZG4ndCBiZSB0aGVtZWQgL0pcbi8vIFRPRE8gbWVyZ2Ugd2l0aCBCYXNlQnV0dG9uIHNvbWUgZGF5XG5leHBvcnQgZGVmYXVsdCB7XG4gIG5hbWU6ICdBcHBCdXR0b24nLFxuICBwcm9wczogeyBjb2xvcjogeyB0eXBlOiBTdHJpbmcsIGRlZmF1bHQ6ICcjMmY1NGViJyB9IH1cbn1cbjwvc2NyaXB0PlxuXG48c3R5bGUgc2NvcGVkPlxuLmFwcC1idG4geyBib3JkZXI6IDA7IGNvbG9yOiB3aGl0ZTsgcGFkZGluZzogMTFweCAyMHB4OyBib3JkZXItcmFkaXVzOiA4cHg7IGZvbnQtc2l6ZTogMTVweDsgY3Vyc29yOiBwb2ludGVyOyB9XG48L3N0eWxlPlxuIl0sIm1hcHBpbmdzIjoiO0FBS0EsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztBQUNwRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDO0FBQ3JDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7RUFDYixDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0VBQ2pCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsRUFBRTtBQUN2RDs7Ozs7d0JBVEUsb0JBQXdFO0lBQWhFLEtBQUssRUFBQyxTQUFTO0lBQUUsS0FBSyxnQ0FBZ0IsWUFBSzs7SUFBSSxZQUFRIiwiaWdub3JlTGlzdCI6W119