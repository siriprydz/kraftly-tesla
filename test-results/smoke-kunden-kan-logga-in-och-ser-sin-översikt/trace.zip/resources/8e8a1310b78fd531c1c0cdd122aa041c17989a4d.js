import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/InvoicesView.vue?vue&type=style&index=0&scoped=e2b6ca3d&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/views/InvoicesView.vue?vue&type=style&index=0&scoped=e2b6ca3d&lang.css"
const __vite__css = "\n.download[data-v-e2b6ca3d] { color: #2f54eb; cursor: pointer; font-size: 14px;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))