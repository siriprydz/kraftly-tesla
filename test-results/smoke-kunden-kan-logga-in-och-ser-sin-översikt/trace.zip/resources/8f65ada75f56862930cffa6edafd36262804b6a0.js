import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/InvoicesView.vue");import { ref, onMounted } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"
import { fetchInvoices } from "/src/services/api.js"
import { formatAmount } from "/src/utils/format.js"


const _sfc_main = {
  __name: 'InvoicesView',
  setup(__props, { expose: __expose }) {
  __expose();

const invoices = ref([])

onMounted(async () => {
  invoices.value = await fetchInvoices()
})

const downloadInvoice = (invoice) => {
  // PDF generation coming in phase 2 per the quote
  console.log('download', invoice.id)
  alert('Nedladdning kommer snart')
}

const __returned__ = { invoices, downloadInvoice, ref, onMounted, get fetchInvoices() { return fetchInvoices }, get formatAmount() { return formatAmount } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, renderList as _renderList, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock, toDisplayString as _toDisplayString, normalizeClass as _normalizeClass } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"

const _hoisted_1 = { class: "card" }
const _hoisted_2 = ["onClick"]

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    _cache[1] || (_cache[1] = _createElementVNode("h1", null, "Fakturor", -1 /* CACHED */)),
    _createElementVNode("div", _hoisted_1, [
      _createElementVNode("table", null, [
        _cache[0] || (_cache[0] = _createElementVNode("tr", null, [
          _createElementVNode("th", null, "Faktura"),
          _createElementVNode("th", null, "Period"),
          _createElementVNode("th", null, "Belopp"),
          _createElementVNode("th", null, "Förfaller"),
          _createElementVNode("th", null, "Status"),
          _createElementVNode("th")
        ], -1 /* CACHED */)),
        (_openBlock(true), _createElementBlock(_Fragment, null, _renderList($setup.invoices, (invoice) => {
          return (_openBlock(), _createElementBlock("tr", {
            key: invoice.id
          }, [
            _createElementVNode("td", null, _toDisplayString(invoice.id), 1 /* TEXT */),
            _createElementVNode("td", null, _toDisplayString(invoice.period), 1 /* TEXT */),
            _createElementVNode("td", null, _toDisplayString($setup.formatAmount(invoice.amount)) + " kr", 1 /* TEXT */),
            _createElementVNode("td", null, _toDisplayString(invoice.due), 1 /* TEXT */),
            _createElementVNode("td", null, [
              _createElementVNode("span", {
                class: _normalizeClass(['status-chip', invoice.status === 'Betald' ? 'status-betald' : 'status-obetald'])
              }, _toDisplayString(invoice.status), 3 /* TEXT, CLASS */)
            ]),
            _createElementVNode("td", null, [
              _createElementVNode("div", {
                class: "download",
                onClick: $event => ($setup.downloadInvoice(invoice))
              }, "Ladda ner", 8 /* PROPS */, _hoisted_2)
            ])
          ]))
        }), 128 /* KEYED_FRAGMENT */))
      ])
    ])
  ]))
}

import "/src/views/InvoicesView.vue?vue&type=style&index=0&scoped=e2b6ca3d&lang.css"

_sfc_main.__hmrId = "e2b6ca3d"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-e2b6ca3d"],['__file',"/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/views/InvoicesView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiSW52b2ljZXNWaWV3LnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxkaXY+XG4gICAgPGgxPkZha3R1cm9yPC9oMT5cbiAgICA8ZGl2IGNsYXNzPVwiY2FyZFwiPlxuICAgICAgPHRhYmxlPlxuICAgICAgICA8dHI+XG4gICAgICAgICAgPHRoPkZha3R1cmE8L3RoPjx0aD5QZXJpb2Q8L3RoPjx0aD5CZWxvcHA8L3RoPjx0aD5Gw7ZyZmFsbGVyPC90aD48dGg+U3RhdHVzPC90aD48dGg+PC90aD5cbiAgICAgICAgPC90cj5cbiAgICAgICAgPHRyIHYtZm9yPVwiaW52b2ljZSBpbiBpbnZvaWNlc1wiIDprZXk9XCJpbnZvaWNlLmlkXCI+XG4gICAgICAgICAgPHRkPnt7IGludm9pY2UuaWQgfX08L3RkPlxuICAgICAgICAgIDx0ZD57eyBpbnZvaWNlLnBlcmlvZCB9fTwvdGQ+XG4gICAgICAgICAgPHRkPnt7IGZvcm1hdEFtb3VudChpbnZvaWNlLmFtb3VudCkgfX0ga3I8L3RkPlxuICAgICAgICAgIDx0ZD57eyBpbnZvaWNlLmR1ZSB9fTwvdGQ+XG4gICAgICAgICAgPHRkPjxzcGFuIDpjbGFzcz1cIlsnc3RhdHVzLWNoaXAnLCBpbnZvaWNlLnN0YXR1cyA9PT0gJ0JldGFsZCcgPyAnc3RhdHVzLWJldGFsZCcgOiAnc3RhdHVzLW9iZXRhbGQnXVwiPnt7IGludm9pY2Uuc3RhdHVzIH19PC9zcGFuPjwvdGQ+XG4gICAgICAgICAgPHRkPjxkaXYgY2xhc3M9XCJkb3dubG9hZFwiIEBjbGljaz1cImRvd25sb2FkSW52b2ljZShpbnZvaWNlKVwiPkxhZGRhIG5lcjwvZGl2PjwvdGQ+XG4gICAgICAgIDwvdHI+XG4gICAgICA8L3RhYmxlPlxuICAgIDwvZGl2PlxuICA8L2Rpdj5cbjwvdGVtcGxhdGU+XG5cbjxzY3JpcHQgc2V0dXA+XG5pbXBvcnQgeyByZWYsIG9uTW91bnRlZCB9IGZyb20gJ3Z1ZSdcbmltcG9ydCB7IGZldGNoSW52b2ljZXMgfSBmcm9tICcuLi9zZXJ2aWNlcy9hcGknXG5pbXBvcnQgeyBmb3JtYXRBbW91bnQgfSBmcm9tICcuLi91dGlscy9mb3JtYXQnXG5cbmNvbnN0IGludm9pY2VzID0gcmVmKFtdKVxuXG5vbk1vdW50ZWQoYXN5bmMgKCkgPT4ge1xuICBpbnZvaWNlcy52YWx1ZSA9IGF3YWl0IGZldGNoSW52b2ljZXMoKVxufSlcblxuY29uc3QgZG93bmxvYWRJbnZvaWNlID0gKGludm9pY2UpID0+IHtcbiAgLy8gUERGIGdlbmVyYXRpb24gY29taW5nIGluIHBoYXNlIDIgcGVyIHRoZSBxdW90ZVxuICBjb25zb2xlLmxvZygnZG93bmxvYWQnLCBpbnZvaWNlLmlkKVxuICBhbGVydCgnTmVkbGFkZG5pbmcga29tbWVyIHNuYXJ0Jylcbn1cbjwvc2NyaXB0PlxuXG48c3R5bGUgc2NvcGVkPlxuLmRvd25sb2FkIHsgY29sb3I6ICMyZjU0ZWI7IGN1cnNvcjogcG9pbnRlcjsgZm9udC1zaXplOiAxNHB4OyB9XG48L3N0eWxlPlxuIl0sIm1hcHBpbmdzIjoiQUFzQkEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDOUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7O0FBRTdDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFdkIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN0QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUN2QyxDQUFDOztBQUVELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDckMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbEM7Ozs7Ozs7Ozs7cUJBakNTLEtBQUssRUFBQyxNQUFNOzs7O3dCQUZuQixvQkFpQk07OEJBaEJKLG9CQUFpQixZQUFiLFVBQVE7SUFDWixvQkFjTSxPQWROLFVBY007TUFiSixvQkFZUTtrQ0FYTixvQkFFSztVQURILG9CQUFnQixZQUFaLFNBQU87VUFBSyxvQkFBZSxZQUFYLFFBQU07VUFBSyxvQkFBZSxZQUFYLFFBQU07VUFBSyxvQkFBa0IsWUFBZCxXQUFTO1VBQUssb0JBQWUsWUFBWCxRQUFNO1VBQUssb0JBQVM7OzJCQUUxRixvQkFPSyw2QkFQaUIsZUFBUSxHQUFuQixPQUFPO2dDQUFsQixvQkFPSztZQVA0QixHQUFHLEVBQUUsT0FBTyxDQUFDLEVBQUU7O1lBQzlDLG9CQUF5Qiw2QkFBbEIsT0FBTyxDQUFDLEVBQUU7WUFDakIsb0JBQTZCLDZCQUF0QixPQUFPLENBQUMsTUFBTTtZQUNyQixvQkFBOEMsNkJBQXZDLG1CQUFZLENBQUMsT0FBTyxDQUFDLE1BQU0sS0FBSSxLQUFHO1lBQ3pDLG9CQUEwQiw2QkFBbkIsT0FBTyxDQUFDLEdBQUc7WUFDbEIsb0JBQXFJO2NBQWpJLG9CQUE0SDtnQkFBckgsS0FBSyxrQ0FBa0IsT0FBTyxDQUFDLE1BQU07a0NBQXdELE9BQU8sQ0FBQyxNQUFNOztZQUN0SCxvQkFBZ0Y7Y0FBNUUsb0JBQXVFO2dCQUFsRSxLQUFLLEVBQUMsVUFBVTtnQkFBRSxPQUFLLGFBQUUsc0JBQWUsQ0FBQyxPQUFPO2lCQUFHLFdBQVMiLCJpZ25vcmVMaXN0IjpbXX0=