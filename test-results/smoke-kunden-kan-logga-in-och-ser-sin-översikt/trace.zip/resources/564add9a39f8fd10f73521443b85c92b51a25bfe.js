import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/ProfileView.vue");import { ref, onMounted } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"
import AppButton from "/src/components/AppButton.vue"
import { useUserStore } from "/src/stores/user.js"


const _sfc_main = {
  __name: 'ProfileView',
  setup(__props, { expose: __expose }) {
  __expose();

const store = useUserStore()
const name = ref('')
const email = ref('')
const address = ref('')

const reset = () => {
  name.value = store.user.name
  email.value = store.user.email
  address.value = store.user.address
}

const save = () => {
  store.save({ name: name.value, email: email.value, address: address.value })
}

onMounted(async () => {
  if (!store.user) await store.load()
  reset()
})

const __returned__ = { store, name, email, address, reset, save, ref, onMounted, AppButton, get useUserStore() { return useUserStore } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, toDisplayString as _toDisplayString, vModelText as _vModelText, withDirectives as _withDirectives, createTextVNode as _createTextVNode, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"

const _hoisted_1 = {
  key: 0,
  class: "card",
  style: {"max-width":"560px"}
}
const _hoisted_2 = { class: "field" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return (_openBlock(), _createElementBlock("div", null, [
    _cache[5] || (_cache[5] = _createElementVNode("h1", null, "Mina uppgifter", -1 /* CACHED */)),
    ($setup.store.user)
      ? (_openBlock(), _createElementBlock("div", _hoisted_1, [
          _createElementVNode("div", _hoisted_2, [
            _cache[3] || (_cache[3] = _createElementVNode("span", { class: "field-label" }, "Kundnummer", -1 /* CACHED */)),
            _createElementVNode("span", null, _toDisplayString($setup.store.user.customerNo), 1 /* TEXT */)
          ]),
          _withDirectives(_createElementVNode("input", {
            type: "text",
            "onUpdate:modelValue": _cache[0] || (_cache[0] = $event => (($setup.name) = $event))
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.name]
          ]),
          _withDirectives(_createElementVNode("input", {
            type: "text",
            "onUpdate:modelValue": _cache[1] || (_cache[1] = $event => (($setup.email) = $event))
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.email]
          ]),
          _withDirectives(_createElementVNode("input", {
            type: "text",
            "onUpdate:modelValue": _cache[2] || (_cache[2] = $event => (($setup.address) = $event))
          }, null, 512 /* NEED_PATCH */), [
            [_vModelText, $setup.address]
          ]),
          _createVNode($setup["AppButton"], {
            color: "#12b76a",
            onClick: $setup.save
          }, {
            default: _withCtx(() => [...(_cache[4] || (_cache[4] = [
              _createTextVNode("Spara ändringar", -1 /* CACHED */)
            ]))]),
            _: 1 /* STABLE */
          }),
          _createElementVNode("button", {
            class: "button-secondary",
            style: {"margin-left":"10px"},
            onClick: $setup.reset
          }, "Ångra")
        ]))
      : _createCommentVNode("v-if", true)
  ]))
}

import "/src/views/ProfileView.vue?vue&type=style&index=0&scoped=0e7a7305&lang.css"

_sfc_main.__hmrId = "0e7a7305"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__scopeId',"data-v-0e7a7305"],['__file',"/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/views/ProfileView.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiUHJvZmlsZVZpZXcudnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cbiAgPGRpdj5cbiAgICA8aDE+TWluYSB1cHBnaWZ0ZXI8L2gxPlxuICAgIDxkaXYgY2xhc3M9XCJjYXJkXCIgc3R5bGU9XCJtYXgtd2lkdGg6NTYwcHhcIiB2LWlmPVwic3RvcmUudXNlclwiPlxuICAgICAgPGRpdiBjbGFzcz1cImZpZWxkXCI+XG4gICAgICAgIDxzcGFuIGNsYXNzPVwiZmllbGQtbGFiZWxcIj5LdW5kbnVtbWVyPC9zcGFuPlxuICAgICAgICA8c3Bhbj57eyBzdG9yZS51c2VyLmN1c3RvbWVyTm8gfX08L3NwYW4+XG4gICAgICA8L2Rpdj5cbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHYtbW9kZWw9XCJuYW1lXCI+XG4gICAgICA8aW5wdXQgdHlwZT1cInRleHRcIiB2LW1vZGVsPVwiZW1haWxcIj5cbiAgICAgIDxpbnB1dCB0eXBlPVwidGV4dFwiIHYtbW9kZWw9XCJhZGRyZXNzXCI+XG4gICAgICA8QXBwQnV0dG9uIGNvbG9yPVwiIzEyYjc2YVwiIEBjbGljaz1cInNhdmVcIj5TcGFyYSDDpG5kcmluZ2FyPC9BcHBCdXR0b24+XG4gICAgICA8YnV0dG9uIGNsYXNzPVwiYnV0dG9uLXNlY29uZGFyeVwiIHN0eWxlPVwibWFyZ2luLWxlZnQ6MTBweFwiIEBjbGljaz1cInJlc2V0XCI+w4VuZ3JhPC9idXR0b24+XG4gICAgPC9kaXY+XG4gIDwvZGl2PlxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdCBzZXR1cD5cbmltcG9ydCB7IHJlZiwgb25Nb3VudGVkIH0gZnJvbSAndnVlJ1xuaW1wb3J0IEFwcEJ1dHRvbiBmcm9tICcuLi9jb21wb25lbnRzL0FwcEJ1dHRvbi52dWUnXG5pbXBvcnQgeyB1c2VVc2VyU3RvcmUgfSBmcm9tICcuLi9zdG9yZXMvdXNlcidcblxuY29uc3Qgc3RvcmUgPSB1c2VVc2VyU3RvcmUoKVxuY29uc3QgbmFtZSA9IHJlZignJylcbmNvbnN0IGVtYWlsID0gcmVmKCcnKVxuY29uc3QgYWRkcmVzcyA9IHJlZignJylcblxuY29uc3QgcmVzZXQgPSAoKSA9PiB7XG4gIG5hbWUudmFsdWUgPSBzdG9yZS51c2VyLm5hbWVcbiAgZW1haWwudmFsdWUgPSBzdG9yZS51c2VyLmVtYWlsXG4gIGFkZHJlc3MudmFsdWUgPSBzdG9yZS51c2VyLmFkZHJlc3Ncbn1cblxuY29uc3Qgc2F2ZSA9ICgpID0+IHtcbiAgc3RvcmUuc2F2ZSh7IG5hbWU6IG5hbWUudmFsdWUsIGVtYWlsOiBlbWFpbC52YWx1ZSwgYWRkcmVzczogYWRkcmVzcy52YWx1ZSB9KVxufVxuXG5vbk1vdW50ZWQoYXN5bmMgKCkgPT4ge1xuICBpZiAoIXN0b3JlLnVzZXIpIGF3YWl0IHN0b3JlLmxvYWQoKVxuICByZXNldCgpXG59KVxuPC9zY3JpcHQ+XG5cbjxzdHlsZSBzY29wZWQ+XG4uZmllbGQgeyBkaXNwbGF5OiBmbGV4OyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47IHBhZGRpbmc6IDhweCAwIDE0cHg7IGZvbnQtc2l6ZTogMTRweDsgfVxuLmZpZWxkLWxhYmVsIHsgY29sb3I6ICM3Yzg2OTg7IH1cbjwvc3R5bGU+XG4iXSwibWFwcGluZ3MiOiJBQWtCQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDbkMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7Ozs7Ozs7QUFFNUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDM0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDcEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7QUFFdEIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNuQzs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25CLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3RTs7QUFFQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3BDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNSLENBQUM7Ozs7Ozs7Ozs7OztFQXJDUSxLQUFLLEVBQUMsTUFBTTtFQUFDLEtBQXVCLEVBQXZCLHFCQUF1Qjs7cUJBQ2xDLEtBQUssRUFBQyxPQUFPOzs7d0JBSHRCLG9CQWFNOzhCQVpKLG9CQUF1QixZQUFuQixnQkFBYztLQUM4QixZQUFLLENBQUMsSUFBSTt1QkFBMUQsb0JBVU0sT0FWTixVQVVNO1VBVEosb0JBR00sT0FITixVQUdNO3NDQUZKLG9CQUEyQyxVQUFyQyxLQUFLLEVBQUMsYUFBYSxJQUFDLFlBQVU7WUFDcEMsb0JBQXdDLCtCQUEvQixZQUFLLENBQUMsSUFBSSxDQUFDLFVBQVU7OzBCQUVoQyxvQkFBa0M7WUFBM0IsSUFBSSxFQUFDLE1BQU07eUVBQVUsV0FBSTs7MEJBQUosV0FBSTs7MEJBQ2hDLG9CQUFtQztZQUE1QixJQUFJLEVBQUMsTUFBTTt5RUFBVSxZQUFLOzswQkFBTCxZQUFLOzswQkFDakMsb0JBQXFDO1lBQTlCLElBQUksRUFBQyxNQUFNO3lFQUFVLGNBQU87OzBCQUFQLGNBQU87O1VBQ25DLGFBQW9FO1lBQXpELEtBQUssRUFBQyxTQUFTO1lBQUUsT0FBSyxFQUFFLFdBQUk7OzhCQUFFLENBQWU7K0JBQWYsaUJBQWU7Ozs7VUFDeEQsb0JBQXVGO1lBQS9FLEtBQUssRUFBQyxrQkFBa0I7WUFBQyxLQUF3QixFQUF4QixzQkFBd0I7WUFBRSxPQUFLLEVBQUUsWUFBSzthQUFFLE9BQUsiLCJpZ25vcmVMaXN0IjpbXX0=