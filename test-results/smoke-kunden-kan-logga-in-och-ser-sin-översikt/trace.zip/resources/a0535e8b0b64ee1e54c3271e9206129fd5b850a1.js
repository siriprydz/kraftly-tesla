import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/LoginView.vue?vue&type=style&index=0&scoped=45f5edd7&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/views/LoginView.vue?vue&type=style&index=0&scoped=45f5edd7&lang.css"
const __vite__css = "\n.login-wrap[data-v-45f5edd7] { display: flex; justify-content: center; padding-top: 60px;\n}\n.login-card[data-v-45f5edd7] { width: 380px;\n}\n.login-logo[data-v-45f5edd7] { height: 34px; margin-bottom: 18px;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))