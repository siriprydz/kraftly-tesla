import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/App.vue");import { useRouter } from "/node_modules/.vite/deps/vue-router.js?v=b23d26c1"


const _sfc_main = {
  __name: 'App',
  setup(__props, { expose: __expose }) {
  __expose();

const router = useRouter()

const logout = () => {
  localStorage.removeItem('kraftly_logged_in')
  router.push('/login')
}

const __returned__ = { router, logout, get useRouter() { return useRouter } }
Object.defineProperty(__returned__, '__isScriptSetup', { enumerable: false, value: true })
return __returned__
}

}
import { createElementVNode as _createElementVNode, createTextVNode as _createTextVNode, resolveComponent as _resolveComponent, withCtx as _withCtx, createVNode as _createVNode, openBlock as _openBlock, createElementBlock as _createElementBlock, createCommentVNode as _createCommentVNode } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"

const _hoisted_1 = {
  key: 0,
  class: "topbar"
}
const _hoisted_2 = { class: "topbar-inner container" }
const _hoisted_3 = { class: "container" }

function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  const _component_RouterLink = _resolveComponent("RouterLink")
  const _component_RouterView = _resolveComponent("RouterView")

  return (_openBlock(), _createElementBlock("div", null, [
    (_ctx.$route.path !== '/login')
      ? (_openBlock(), _createElementBlock("header", _hoisted_1, [
          _createElementVNode("div", _hoisted_2, [
            _cache[4] || (_cache[4] = _createElementVNode("img", {
              src: "/src/assets/logo.svg",
              class: "logo"
            }, null, -1 /* CACHED */)),
            _createElementVNode("nav", null, [
              _createVNode(_component_RouterLink, { to: "/" }, {
                default: _withCtx(() => [...(_cache[0] || (_cache[0] = [
                  _createTextVNode("Översikt", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }),
              _createVNode(_component_RouterLink, { to: "/fakturor" }, {
                default: _withCtx(() => [...(_cache[1] || (_cache[1] = [
                  _createTextVNode("Fakturor", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }),
              _createVNode(_component_RouterLink, { to: "/flytt" }, {
                default: _withCtx(() => [...(_cache[2] || (_cache[2] = [
                  _createTextVNode("Flyttanmälan", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }),
              _createVNode(_component_RouterLink, { to: "/profil" }, {
                default: _withCtx(() => [...(_cache[3] || (_cache[3] = [
                  _createTextVNode("Mina uppgifter", -1 /* CACHED */)
                ]))]),
                _: 1 /* STABLE */
              }),
              _createElementVNode("span", {
                class: "logout",
                onClick: $setup.logout
              }, "Logga ut")
            ])
          ])
        ]))
      : _createCommentVNode("v-if", true),
    _createElementVNode("main", _hoisted_3, [
      _createVNode(_component_RouterView)
    ])
  ]))
}

import "/src/App.vue?vue&type=style&index=0&lang.css"

_sfc_main.__hmrId = "7a7a37b1"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/App.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJuYW1lcyI6W10sInNvdXJjZXMiOlsiQXBwLnZ1ZSJdLCJzb3VyY2VzQ29udGVudCI6WyI8dGVtcGxhdGU+XG4gIDxkaXY+XG4gICAgPGhlYWRlciBjbGFzcz1cInRvcGJhclwiIHYtaWY9XCIkcm91dGUucGF0aCAhPT0gJy9sb2dpbidcIj5cbiAgICAgIDxkaXYgY2xhc3M9XCJ0b3BiYXItaW5uZXIgY29udGFpbmVyXCI+XG4gICAgICAgIDxpbWcgc3JjPVwiLi9hc3NldHMvbG9nby5zdmdcIiBjbGFzcz1cImxvZ29cIj5cbiAgICAgICAgPG5hdj5cbiAgICAgICAgICA8Um91dGVyTGluayB0bz1cIi9cIj7DlnZlcnNpa3Q8L1JvdXRlckxpbms+XG4gICAgICAgICAgPFJvdXRlckxpbmsgdG89XCIvZmFrdHVyb3JcIj5GYWt0dXJvcjwvUm91dGVyTGluaz5cbiAgICAgICAgICA8Um91dGVyTGluayB0bz1cIi9mbHl0dFwiPkZseXR0YW5tw6RsYW48L1JvdXRlckxpbms+XG4gICAgICAgICAgPFJvdXRlckxpbmsgdG89XCIvcHJvZmlsXCI+TWluYSB1cHBnaWZ0ZXI8L1JvdXRlckxpbms+XG4gICAgICAgICAgPHNwYW4gY2xhc3M9XCJsb2dvdXRcIiBAY2xpY2s9XCJsb2dvdXRcIj5Mb2dnYSB1dDwvc3Bhbj5cbiAgICAgICAgPC9uYXY+XG4gICAgICA8L2Rpdj5cbiAgICA8L2hlYWRlcj5cbiAgICA8bWFpbiBjbGFzcz1cImNvbnRhaW5lclwiPlxuICAgICAgPFJvdXRlclZpZXcgLz5cbiAgICA8L21haW4+XG4gIDwvZGl2PlxuPC90ZW1wbGF0ZT5cblxuPHNjcmlwdCBzZXR1cD5cbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gJ3Z1ZS1yb3V0ZXInXG5cbmNvbnN0IHJvdXRlciA9IHVzZVJvdXRlcigpXG5cbmNvbnN0IGxvZ291dCA9ICgpID0+IHtcbiAgbG9jYWxTdG9yYWdlLnJlbW92ZUl0ZW0oJ2tyYWZ0bHlfbG9nZ2VkX2luJylcbiAgcm91dGVyLnB1c2goJy9sb2dpbicpXG59XG48L3NjcmlwdD5cblxuPHN0eWxlPlxuLnRvcGJhciB7IGJhY2tncm91bmQ6ICMxMDFkM2Q7IH1cbi50b3BiYXItaW5uZXIgeyBkaXNwbGF5OiBmbGV4OyBhbGlnbi1pdGVtczogY2VudGVyOyBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47IHBhZGRpbmctdG9wOiAxNHB4OyBwYWRkaW5nLWJvdHRvbTogMTRweDsgfVxuLmxvZ28geyBoZWlnaHQ6IDMwcHg7IH1cbi50b3BiYXIgbmF2IGEsIC5sb2dvdXQge1xuICBjb2xvcjogI2MyY2JlNDtcbiAgdGV4dC1kZWNvcmF0aW9uOiBub25lO1xuICBtYXJnaW4tbGVmdDogMjJweDtcbiAgZm9udC1zaXplOiAxNC41cHg7XG4gIGN1cnNvcjogcG9pbnRlcjtcbn1cbi50b3BiYXIgbmF2IGEucm91dGVyLWxpbmstYWN0aXZlIHsgY29sb3I6ICNmZmY7IGZvbnQtd2VpZ2h0OiA2MDA7IH1cbjwvc3R5bGU+XG4iXSwibWFwcGluZ3MiOiJBQXFCQSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7OztBQUVyQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDOztBQUV6QixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNyQixDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM3QyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3RCOzs7Ozs7Ozs7Ozs7RUExQlksS0FBSyxFQUFDLFFBQVE7O3FCQUNmLEtBQUssRUFBQyx3QkFBd0I7cUJBVy9CLEtBQUssRUFBQyxXQUFXOzs7Ozs7d0JBYnpCLG9CQWdCTTtLQWZ5QixXQUFNLENBQUMsSUFBSTt1QkFBeEMsb0JBV1MsVUFYVCxVQVdTO1VBVlAsb0JBU00sT0FUTixVQVNNO3NDQVJKLG9CQUEwQztjQUFyQyxHQUFHLEVBQUMsc0JBQW1CO2NBQUMsS0FBSyxFQUFDLE1BQU07O1lBQ3pDLG9CQU1NO2NBTEosYUFBd0MseUJBQTVCLEVBQUUsRUFBQyxHQUFHO2tDQUFDLENBQVE7bUNBQVIsVUFBUTs7OztjQUMzQixhQUFnRCx5QkFBcEMsRUFBRSxFQUFDLFdBQVc7a0NBQUMsQ0FBUTttQ0FBUixVQUFROzs7O2NBQ25DLGFBQWlELHlCQUFyQyxFQUFFLEVBQUMsUUFBUTtrQ0FBQyxDQUFZO21DQUFaLGNBQVk7Ozs7Y0FDcEMsYUFBb0QseUJBQXhDLEVBQUUsRUFBQyxTQUFTO2tDQUFDLENBQWM7bUNBQWQsZ0JBQWM7Ozs7Y0FDdkMsb0JBQW9EO2dCQUE5QyxLQUFLLEVBQUMsUUFBUTtnQkFBRSxPQUFLLEVBQUUsYUFBTTtpQkFBRSxVQUFROzs7OztJQUluRCxvQkFFTyxRQUZQLFVBRU87TUFETCxhQUFjIiwiaWdub3JlTGlzdCI6W119