import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/views/DashboardView.vue?vue&type=style&index=0&scoped=336c5134&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/views/DashboardView.vue?vue&type=style&index=0&scoped=336c5134&lang.css"
const __vite__css = "\n.hero[data-v-336c5134] {\n  width: 100%;\n  border-radius: 10px;\n  margin-bottom: 18px;\n}\n.stats[data-v-336c5134] {\n  display: grid;\n  grid-template-columns: 1fr 1fr 1fr;\n  gap: 20px;\n}\n.stat-label[data-v-336c5134] {\n  font-size: 13px;\n  color: #7c8698;\n  margin-bottom: 6px;\n}\n.stat-value[data-v-336c5134] {\n  font-size: 26px;\n  font-weight: 700;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))