import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/BaseButton.vue");const _sfc_main = {  }
import { createCommentVNode as _createCommentVNode, renderSlot as _renderSlot, createElementVNode as _createElementVNode, Fragment as _Fragment, openBlock as _openBlock, createElementBlock as _createElementBlock } from "/node_modules/.vite/deps/vue.js?v=b23d26c1"

const _hoisted_1 = { class: "btn" }

function _sfc_render(_ctx, _cache) {
  return (_openBlock(), _createElementBlock(_Fragment, null, [
    _createCommentVNode(" generic button, use this one! /M "),
    _createElementVNode("button", _hoisted_1, [
      _renderSlot(_ctx.$slots, "default")
    ])
  ], 2112 /* STABLE_FRAGMENT, DEV_ROOT_FRAGMENT */))
}


_sfc_main.__hmrId = "2d3a2488"
typeof __VUE_HMR_RUNTIME__ !== 'undefined' && __VUE_HMR_RUNTIME__.createRecord(_sfc_main.__hmrId, _sfc_main)
import.meta.hot.on('file-changed', ({ file }) => {
  __VUE_HMR_RUNTIME__.CHANGED_FILE = file
})
import.meta.hot.accept(mod => {
  if (!mod) return
  const { default: updated, _rerender_only } = mod
  if (_rerender_only) {
    __VUE_HMR_RUNTIME__.rerender(updated.__hmrId, updated.render)
  } else {
    __VUE_HMR_RUNTIME__.reload(updated.__hmrId, updated)
  }
})
import _export_sfc from "/@id/__x00__plugin-vue:export-helper"
export default /*#__PURE__*/_export_sfc(_sfc_main, [['render',_sfc_render],['__file',"/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/components/BaseButton.vue"]])
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiL1VzZXJzL2pha29iaGFubmEvRG9jdW1lbnRzL1Byb2pla3QtYXJiZXRlbi9rcmFmdGx5LXRlc2xhL3NyYy9jb21wb25lbnRzL0Jhc2VCdXR0b24udnVlIiwibmFtZXMiOltdLCJzb3VyY2VzIjpbIkJhc2VCdXR0b24udnVlIl0sInNvdXJjZXNDb250ZW50IjpbIjx0ZW1wbGF0ZT5cbiAgPCEtLSBnZW5lcmljIGJ1dHRvbiwgdXNlIHRoaXMgb25lISAvTSAtLT5cbiAgPGJ1dHRvbiBjbGFzcz1cImJ0blwiPjxzbG90IC8+PC9idXR0b24+XG48L3RlbXBsYXRlPlxuIl0sIm1hcHBpbmdzIjoiOzs7cUJBRVUsS0FBSyxFQUFDLEtBQUs7Ozs7SUFEbkIseURBQXlDO0lBQ3pDLG9CQUFxQyxVQUFyQyxVQUFxQztNQUFqQixZQUFRIiwiaWdub3JlTGlzdCI6W119