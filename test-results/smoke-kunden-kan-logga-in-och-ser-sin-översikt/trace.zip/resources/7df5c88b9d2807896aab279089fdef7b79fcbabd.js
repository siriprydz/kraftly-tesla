import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/AppButton.vue?vue&type=style&index=0&scoped=19765ba3&lang.css");import { updateStyle as __vite__updateStyle, removeStyle as __vite__removeStyle } from "/@vite/client"
const __vite__id = "/Users/jakobhanna/Documents/Projekt-arbeten/kraftly-tesla/src/components/AppButton.vue?vue&type=style&index=0&scoped=19765ba3&lang.css"
const __vite__css = "\n.app-btn[data-v-19765ba3] { border: 0; color: white; padding: 11px 20px; border-radius: 8px; font-size: 15px; cursor: pointer;\n}\n"
__vite__updateStyle(__vite__id, __vite__css)
import.meta.hot.accept()
import.meta.hot.prune(() => __vite__removeStyle(__vite__id))